//
//  ViewController.swift
//  Prime
//
//  Created by Khadija Naqvi on 6/9/18.
//  Copyright © 2018 djnaqvi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userEnteredNum: UITextField!
    @IBOutlet weak var userOutput: UILabel!
    @IBAction func isItPrime(_ sender: Any) {
        if let userEnteredString = userEnteredNum.text {
            let userEnteredInt = Int(userEnteredString)
            if let num = userEnteredInt {
                var isPrime = true
                if num == 1 {
                    isPrime = false
                }
                var i = 2
                
                while i < num {
                    
                    if num % i == 0 {
                        isPrime = false
                    }
                    i += 1
                }
                if isPrime {
                    userOutput.text = "\(num) is prime"
                } else {
                    userOutput.text = "\(num) is not prime"
                }
            }
        } else {
            userOutput.text = "Enter a positive whole number"
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//
//  ViewController.swift
//  Finger Guess
//
//  Created by Khadija Naqvi on 5/31/18.
//  Copyright © 2018 djnaqvi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var guess: UITextField!
    
    @IBAction func user(_ sender: Any) {
        let fingers = String(arc4random_uniform(6))
        
        if (guess.text == fingers) {
            result.text = "You guessed right!"
        }else {
            result.text = "Sorry, the answer was \(fingers)"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


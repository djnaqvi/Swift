//: Playground - noun: a place where people can play

import UIKit

var array = [Double]()
array = [8,7,19,28]
for (index, value) in array.enumerated() {
    array[index] = value/2
}
print(array)

//: Playground - noun: a place where people can play

import UIKit
/*
var array = [Decimal]()
array = [3.87, 7.1, 8.9]
array.remove(at: 1)
array.append(array[0]*array[1])

print(array)

let menu = ["pizza": 10.99, "ice cream": 4.99, "salad": 8.99]
print("The total cost of my meal is: \(menu["pizza"]! + menu["ice cream"]!)")
*/

let username = "djnaqvi"
let password = "wearepsu "

if username == "djnaqvi" && password == "wearepsu"{
    print("Welcome!")
} else if(username == "djnaqvi"){
    print("Incorrect password")
} else if(password == "wearepsu"){
    print("Incorrect username")
} else{
    print("Sorry, you cannot login")
}


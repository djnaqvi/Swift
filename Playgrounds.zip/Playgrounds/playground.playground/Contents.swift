//: Playground - noun: a place where people can play

import UIKit

var num = 1

while num <= 20 {
    print(num*7)
    num += 1
}

//: Playground - noun: a place where people can play

import UIKit

var a  = 5.76
var b = 8

print("The product of \(a) and \(b) is: \(a*Double(b))")

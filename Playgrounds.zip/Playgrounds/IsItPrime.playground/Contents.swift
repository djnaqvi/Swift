//: Playground - noun: a place where people can play

import UIKit

let num = 200

var isPrime = true

var i = 2

while i < num {
    
    if num % i == 0 {
        isPrime = false
    }
    i += 1
}

print(isPrime)
